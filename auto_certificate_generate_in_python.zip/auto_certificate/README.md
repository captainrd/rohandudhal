# Cerificate maker
## About the project
a python proggram used to automate the making the certificates


## Build with 
- Python3 

## Getting Started
This is an example of how you may give instructions on setting up your project locally. To get a local copy up and running follow these simple example steps.

## Prerequisites

```cmd
pip install -r requirements.txt
```
## Enviroment used for running 
- windows 11
- os had the font installed (not tested without installing the font)
## Usage
Command to use
```cmd
python3 certificate.py <csv file with names> <font name> <font size on certificate for student name> <certificate template image> <output folder name in current directory>

```

```cmd
python3 certificate.py list.csv Charm-Bold.ttf 60 Telperium_Updated_Cert.jpg output_certificate
```

- **list.csv**
    - has the list of student names in csv format


# Contact
- 
